import React, { useState } from 'react';
import { Download, Terminal } from 'lucide-react';
import { useMusicStore } from '../lib/store';

export function CommandBar() {
  const { addToLibrary } = useMusicStore();
  const [urlInput, setUrlInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    
    addToLibrary(urlInput);
    setUrlInput('');
  };

  return (
    <div className="border-b border-border bg-card p-4">
      <div className="mb-2 flex items-center gap-2 text-xs font-mono text-primary/80">
        <Terminal className="w-3 h-3" />
        <span>COMMAND_INPUT // PASTE_URL_HERE</span>
      </div>
      
      <form onSubmit={handleSubmit} className="flex gap-0 border border-border focus-within:border-primary/70 transition-colors bg-black">
        <div className="pl-3 py-3 flex items-center justify-center bg-muted/20 border-r border-border">
          <span className="text-muted-foreground font-mono text-sm">{'>'}</span>
        </div>
        <input
          type="text"
          value={urlInput}
          onChange={(e) => setUrlInput(e.target.value)}
          className="flex-1 bg-transparent px-3 py-3 font-mono text-sm text-foreground focus:outline-none placeholder:text-muted-foreground/50"
          placeholder="https://www.youtube.com/watch?v=..."
        />
        <button
          type="submit"
          disabled={!urlInput}
          className="px-6 bg-white text-black hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed font-bold text-xs uppercase tracking-widest transition-colors flex items-center gap-2"
        >
          <Download className="w-4 h-4" />
          ACQUIRE
        </button>
      </form>
      
      <div className="mt-2 flex justify-between text-[10px] text-muted-foreground font-mono uppercase">
        <span>Status: READY</span>
        <span>Module: YT-DLP-V2.1</span>
      </div>
    </div>
  );
}
