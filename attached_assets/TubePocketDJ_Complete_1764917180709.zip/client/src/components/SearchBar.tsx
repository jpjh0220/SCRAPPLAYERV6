import React from 'react';
import { Search, Loader2 } from 'lucide-react';
import { useMusicStore } from '../lib/store';

const API_KEY = "AIzaSyCmf-qsQy5xkgnvU5kCR7yvK-Fp1MFzs_s"; // Hardcoded as requested for prototype

export function SearchBar() {
  const { searchQuery, setSearchQuery, performSearch, isSearching } = useMusicStore();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(API_KEY);
  };

  return (
    <div className="p-4 border-b border-border bg-card/50 backdrop-blur-sm">
      <form onSubmit={handleSearch} className="flex gap-2">
        <div className="relative flex-1 group">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="block w-full pl-10 pr-3 py-2 border border-input bg-background text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all font-mono"
            placeholder="SEARCH_YOUTUBE_DATABASE..."
          />
        </div>
        <button
          type="submit"
          disabled={isSearching}
          className="px-4 py-2 bg-primary text-primary-foreground text-sm font-bold uppercase tracking-wider hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center gap-2"
        >
          {isSearching && <Loader2 className="h-4 w-4 animate-spin" />}
          {isSearching ? 'SCANNING' : 'EXECUTE'}
        </button>
      </form>
    </div>
  );
}
