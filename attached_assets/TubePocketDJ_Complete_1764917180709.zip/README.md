# TubePocketDJ

A full-stack YouTube to MP3 downloader and music library application. Search YouTube videos, download them as high-quality MP3 files, and play them directly in your browser.

## Features

- **YouTube Search**: Search for videos using the YouTube Data API
- **MP3 Downloads**: Download videos as high-quality MP3 files using yt-dlp
- **Music Library**: Organize and browse your downloaded tracks
- **Built-in Player**: Play your music directly in the browser
- **Real-time Progress**: Track download progress in real-time

## Tech Stack

- **Frontend**: React, TypeScript, TailwindCSS, Zustand (state management)
- **Backend**: Express.js, Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Download Engine**: yt-dlp (Python)
- **Audio Processing**: FFmpeg

## Prerequisites

Before running this application, ensure you have the following installed:

- **Node.js** v20 or higher
- **Python** 3.11 or higher
- **PostgreSQL** 16 or higher
- **FFmpeg** (for audio conversion)
- **yt-dlp** (Python package for YouTube downloads)

## Installation

### 1. Clone the Repository

```bash
git clone <your-repo-url>
cd TubePocketDJ
```

### 2. Install Node.js Dependencies

```bash
npm install
```

### 3. Install Python Dependencies

```bash
pip install yt-dlp
# or using pip3
pip3 install yt-dlp
```

### 4. Install FFmpeg

**Ubuntu/Debian:**
```bash
sudo apt update && sudo apt install ffmpeg
```

**macOS (Homebrew):**
```bash
brew install ffmpeg
```

**Windows:**
Download from https://ffmpeg.org/download.html and add to PATH

### 5. Set Up PostgreSQL Database

Create a PostgreSQL database and set the connection URL:

```bash
export DATABASE_URL="postgresql://username:password@localhost:5432/tubepocketdj"
```

### 6. Run Database Migrations

```bash
npm run db:push
```

## Configuration

### Environment Variables

Create a `.env` file in the root directory:

```env
# Database connection
DATABASE_URL=postgresql://username:password@localhost:5432/tubepocketdj

# Server port (optional, defaults to 5000)
PORT=5000

# Node environment
NODE_ENV=development
```

### YouTube API Key (Optional)

The search feature uses a YouTube Data API key. To use your own key, update the `API_KEY` constant in `client/src/components/SearchBar.tsx`:

```typescript
const API_KEY = "YOUR_YOUTUBE_API_KEY";
```

Get a free API key from the [Google Cloud Console](https://console.cloud.google.com/).

## Running the Application

### Development Mode

```bash
npm run dev
```

This starts the full-stack development server on port 5000.

### Production Build

```bash
# Build the application
npm run build

# Start production server
npm run start
```

## Project Structure

```
TubePocketDJ/
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # React components
│   │   │   ├── CommandBar.tsx    # URL input for downloads
│   │   │   ├── Library.tsx       # Music library display
│   │   │   ├── Player.tsx        # Audio player
│   │   │   ├── ResultList.tsx    # Search results
│   │   │   └── SearchBar.tsx     # YouTube search
│   │   ├── lib/
│   │   │   └── store.ts          # Zustand state management
│   │   └── pages/
│   │       └── home.tsx          # Main page
│   └── index.html
├── server/                 # Backend Express server
│   ├── index.ts           # Server entry point
│   ├── routes.ts          # API routes (download, tracks, audio)
│   └── storage.ts         # Database operations
├── shared/
│   └── schema.ts          # Drizzle database schema
├── music/                  # Downloaded MP3 files (created automatically)
└── package.json
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/tracks` | Get all downloaded tracks |
| POST | `/api/download` | Start a new download (body: `{url: "youtube-url"}`) |
| GET | `/api/audio/:videoId` | Stream audio file for playback |

## Deployment

### Replit

This application is optimized for Replit deployment:
1. Import the project to Replit
2. The `.replit` file is pre-configured
3. Add `DATABASE_URL` to Secrets
4. Click Run

### Docker (Coming Soon)

### Heroku

1. Create a Heroku app with PostgreSQL addon
2. Set the buildpacks:
   ```bash
   heroku buildpacks:add heroku/nodejs
   heroku buildpacks:add heroku/python
   ```
3. Deploy and set `DATABASE_URL` (auto-configured with PostgreSQL addon)

### VPS/Self-Hosted

1. Install all prerequisites (Node.js, Python, PostgreSQL, FFmpeg, yt-dlp)
2. Clone and install dependencies
3. Set up PostgreSQL and configure `DATABASE_URL`
4. Run with PM2 or systemd for process management:
   ```bash
   npm run build
   pm2 start npm --name "tubepocketdj" -- run start
   ```

## Troubleshooting

### yt-dlp Issues

If downloads fail, ensure yt-dlp is up to date:
```bash
pip install --upgrade yt-dlp
```

### FFmpeg Not Found

Ensure FFmpeg is installed and accessible in your PATH:
```bash
ffmpeg -version
```

### Database Connection Errors

Verify your `DATABASE_URL` is correct and PostgreSQL is running:
```bash
psql $DATABASE_URL -c "SELECT 1"
```

## License

MIT License

## Credits

- [yt-dlp](https://github.com/yt-dlp/yt-dlp) - YouTube download engine
- [FFmpeg](https://ffmpeg.org/) - Audio/video processing
- [Drizzle ORM](https://orm.drizzle.team/) - Database ORM
- [TailwindCSS](https://tailwindcss.com/) - Styling
