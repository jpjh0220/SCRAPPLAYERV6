import { Copy, Check, ExternalLink } from 'lucide-react';
import { useMusicStore } from '../lib/store';
import { useState } from 'react';

export function ResultList() {
  const { searchResults } = useMusicStore();
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const handleCopy = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (searchResults.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground p-8 font-mono text-xs opacity-50">
        <div className="w-16 h-16 border border-dashed border-muted-foreground/30 rounded-full flex items-center justify-center mb-4">
          <span className="text-4xl">?</span>
        </div>
        <p>NO_DATA_RECEIVED</p>
        <p>WAITING_FOR_QUERY...</p>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
      <div className="text-xs font-mono text-muted-foreground mb-2 flex justify-between">
        <span>RESULTS_FOUND: {searchResults.length}</span>
        <span>SOURCE: YOUTUBE_API_V3</span>
      </div>
      
      {searchResults.map((result) => (
        <div 
          key={result.id} 
          className="group flex gap-3 p-3 border border-border bg-card/30 hover:bg-card hover:border-primary/50 transition-all duration-200"
        >
          <div className="relative w-32 aspect-video bg-black shrink-0 overflow-hidden border border-border/50">
            <img 
              src={result.thumbnail} 
              alt={result.title} 
              className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" 
            />
            <div className="absolute bottom-0 right-0 bg-black/80 text-[10px] font-mono px-1 text-white">
              ID:{result.id}
            </div>
          </div>
          
          <div className="flex-1 min-w-0 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-medium text-foreground truncate pr-2 font-sans" title={result.title}>
                {result.title}
              </h3>
              <p className="text-xs text-muted-foreground font-mono mt-1 truncate">
                {result.channel}
              </p>
            </div>
            
            <div className="flex items-center gap-2 mt-2">
              <button
                onClick={() => handleCopy(result.url, result.id)}
                className="flex items-center gap-1.5 px-2 py-1 text-[10px] font-mono uppercase border border-primary/30 text-primary hover:bg-primary/10 hover:border-primary transition-colors"
              >
                {copiedId === result.id ? (
                  <>
                    <Check className="w-3 h-3" />
                    COPIED
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    COPY_URL
                  </>
                )}
              </button>
              
              <a 
                href={result.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-1 text-muted-foreground hover:text-foreground transition-colors"
              >
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
